# diopy

The package dior is the part of scDIOR, which is used for single-cell data IO between R and Python (Python version)

## installation
We recommend using pip for installation
```shell
pip install diopy
# git clone https://github.com/JiekaiLab/diopy.git
# cd diopy
# python setup.py install
```



