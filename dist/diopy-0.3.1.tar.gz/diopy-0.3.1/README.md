# diopy
single-cell data IO between R and Python (Python version)



## installation

```shell
git clone https://github.com/JiekaiLab/diopy.git
cd diopy
python setup.py install
```



